/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphique;
import javax.swing.*;
import java.awt.event.*;
import connexion.*;
import java.awt.Color;
import java.sql.SQLException;
/**
 *
 * @author Rémi
 */
public class Fenetre extends JFrame {
    

    /**
     *
     */
    public Fenetre(){
        super("Gestion de l'école");
        WindowListener l = new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                System.exit(0);
            }
        };
        addWindowListener(l);
        JPanel panel = new JPanel();
        panel.setBackground(Color.blue);
        
        JButton connectb = new JButton("Se connecter");
        panel.add(connectb);
        connectb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent a){
                try{
                    Connexion C = new Connexion("java2019","root","");
                    System.out.println("Connexion réussie!");
                    }
                catch(SQLException e){
                    System.out.println("Probleme BDD (SQL)");
                }
                catch(ClassNotFoundException p){
                    System.out.println("Probleme BDD (Class)");
                }   
            }
        }
        );
        
        JButton look4 = new JButton("Rechercher");
        panel.add(look4);
        
        setContentPane(panel);
        setSize(200,100);
        setVisible(true);
                
    }
}
