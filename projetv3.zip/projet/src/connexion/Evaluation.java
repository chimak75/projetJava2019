/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

/**
 *
 * @author Rémi
 */
public class Evaluation {
    public String ID;
    public String note;
    public String appréciation;
    public String detail;
    public Evaluation(String[] l){
        this.ID = l[0];
        this.note = l[1];
        this.appréciation= l[2];  
        this.detail= l[3];  
    }
}
