/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

/**
 *
 * @author Rémi
 */
public class Bulletin {
    public String ID;
    public String appréciation;
    public String trimestre;
    public String inscription;
    public Bulletin(String[] l){
        this.ID = l[0];
        this.appréciation= l[1];
        this.trimestre = l[2]; 
        this.inscription = l[3];
    }
}
