/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

/**
 *
 * @author Rémi
 */
public class Enseignement {
    public String ID;
    public String enseignant;
    public String classe;
    public String discipline;
    public Enseignement (String[] l){
        this.ID = l[0];
        this.enseignant= l[1];
        this.classe = l[2]; 
        this.discipline = l[3];
    }
}
