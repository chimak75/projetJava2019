/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

/**
 *
 * @author Rémi
 */
public class Classe {
    public String ID;
    public String nom;
    public String niveau;
    public Classe(String[] l){
        this.ID = l[0];
        this.nom= l[1];
        this.niveau = l[2];
    }
}
